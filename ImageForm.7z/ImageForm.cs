﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace defect
{
    public partial class ImageForm : Form
    {
        public ImageForm()
        {
            
            InitializeComponent();
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            //pictureBox1.Dock = DockStyle.Fill; //填充整个Form大小
            pictureBox1.BackColor = Color.Transparent; //设置背景色透明
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //将数据置于系统剪贴板中，并指定在退出程序后是否是否将数据保留在剪贴板中
            //Clipboard.SetDataObject(imageList1.Images[i], false);
            Image image = Clipboard.GetImage();
            if (image != null)
            {
                pictureBox1.Image = image;
                imageList1.Images.Add("aaa",pictureBox1.Image);
                Bitmap bmPic = new Bitmap(image);
                Point ptLoction = new Point(bmPic.Size);
                if (ptLoction.X > pictureBox1.Size.Width || ptLoction.Y > pictureBox1.Size.Height)
                {
                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else
                {
                    pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                }
            }
            //pictureBox1.Image = Clipboard.GetImage();
            
            MessageBox.Show(imageList1.Images.Count.ToString(), "提示信息");
        }

        private void ImageForm_Load(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tt();
        }


        private void tt() {
            imageList1.Images.RemoveByKey("aaa");
            Image iOld = this.pictureBox1.Image;
            this.pictureBox1.Image = null;
            if (iOld != null)
            {
                iOld.Dispose();
                MessageBox.Show("清除成功！", imageList1.Images.Count+"张", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }

        }

        private string pic = "";
        private void button3_Click(object sender, EventArgs e)
        {
            if (this.pictureBox1.Image != null)
            {
                Bitmap bmp = new Bitmap(this.pictureBox1.Image);
                MemoryStream memStream = new MemoryStream();
                bmp.Save(memStream, System.Drawing.Imaging.ImageFormat.Bmp);
                memStream.Seek(0, SeekOrigin.Begin);
                byte[] btImage = new byte[memStream.Length];
                memStream.Read(btImage, 0, btImage.Length);
                memStream.Close();
                pic = Convert.ToBase64String(btImage);
                MessageBox.Show("保存成功", pic.Length+":长度", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else {
                MessageBox.Show("没有图片", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(pic))
            {
                //直接返Base64码转成数组
                byte[] imageBytes = Convert.FromBase64String(pic);
                //读入MemoryStream对象
                MemoryStream memoryStream = new MemoryStream(imageBytes, 0, imageBytes.Length);
                memoryStream.Write(imageBytes, 0, imageBytes.Length);
                Image image = Image.FromStream(memoryStream);
                memoryStream.Close();
                this.pictureBox1.Image = image;
                MessageBox.Show("加载成功", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

            }
        }
    }
}
