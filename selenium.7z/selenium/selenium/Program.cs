﻿// See https://aka.ms/new-console-template for more information
using Selenium;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;

Console.WriteLine("Hello, World!");

//ChromeDriver driver= new ChromeDriver();
//driver.Navigate().GoToUrl("http://www.baidu.com");

var driver = new EdgeDriver();
try
{
    driver.Url = "https://bing.com";

    var element = driver.FindElement(By.Id("sb_form_q"));
    element.SendKeys("WebDriver");
    element.Submit();

    Thread.Sleep(5000);
}
finally
{
    driver.Quit();
}
